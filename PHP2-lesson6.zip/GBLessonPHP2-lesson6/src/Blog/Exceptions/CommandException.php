<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class CommandException extends AppException
{

}