<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

final class AuthException extends AppException
{

}