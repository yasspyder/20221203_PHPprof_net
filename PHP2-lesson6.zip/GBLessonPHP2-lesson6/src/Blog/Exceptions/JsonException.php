<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class JsonException extends AppException
{

}