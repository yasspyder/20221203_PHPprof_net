<?php

namespace GeekBrains\PHPUnit\Container;

class SomeClassWithoutDependencies
{

}