<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class InvalidArgumentException extends AppException
{

}