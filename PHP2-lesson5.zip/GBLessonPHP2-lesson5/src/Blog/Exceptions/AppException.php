<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class AppException extends \Exception
{

}