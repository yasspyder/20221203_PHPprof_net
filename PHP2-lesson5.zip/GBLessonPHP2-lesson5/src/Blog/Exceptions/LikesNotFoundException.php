<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class LikesNotFoundException extends AppException
{

}